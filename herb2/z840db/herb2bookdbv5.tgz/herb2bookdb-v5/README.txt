herb2bookdb-v5 — 《풀이 약이 되기까지》 세계 허브의 과학사 (가제)
만든 때 2026-10-31T14:57:26+09:00 / 저장소 커밋 4110411

폴더 구성
  herb2bookdb-v5.db  SQLite 한 파일. 표: meta parts chapters sections refs figures(PNG 컬러·흑백 포함) tables_ figscripts figdata typeset(CSS·판형·글꼴) scripts docs pagemap(쪽별 지도·아래 빈칸) old_* files
  pdf/                  컬러판·흑백판 PDF
  src/                  원고·그림 스크립트·표 CSV·빌드 도구 원본 (이대로 python3 tools/build-pdf.py both 로 재조판 가능; 코퍼스 제외)
  SHA256SUMS            전체 파일 해시

조회 예
  sqlite3 herb2bookdb-v5.db "select no,title,page_start_color,page_end_color from chapters"
  python3 -c "import sqlite3;c=sqlite3.connect('herb2bookdb-v5.db');print(c.execute('select label,title,page_color from figures limit 5').fetchall())"
