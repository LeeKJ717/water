herb2bookdb-v7 — 《풀이 약이 되기까지》 세계 허브의 과학사 (가제)
만든 때 2026-11-01T09:57:55+09:00 / 저장소 커밋 3d9229a

폴더 구성
  herb2bookdb-v7.db  SQLite 한 파일. 표: meta parts chapters sections refs figures(PNG 컬러·흑백 포함) tables_ figscripts figdata typeset(CSS·판형·글꼴) scripts docs pagemap(쪽별 지도·아래 빈칸) corpus(수집 논문 12,155편: 제목·초록·저자·태그, relevant=본문 관련 7,182편, used_in_book=본문 인용) refs_link(참고문헌↔논문 연결) crossref_meta(서지 조회 원본) parsed(장별 파싱 결과) old_* files
  pdf/                  컬러판·흑백판 PDF
  src/                  원고·그림 스크립트·표 CSV·빌드 도구 원본 (이대로 python3 tools/build-pdf.py both 로 재조판 가능; 코퍼스 제외)
  SHA256SUMS            전체 파일 해시

2판·수정용 사용
  논문 말뭉치 꺼내기: sqlite3 herb2bookdb-v7.db "select id,doi,title,year,journal from corpus where relevant=1"
  본문에 인용한 논문: select * from corpus where used_in_book=1
  파싱 결과 복원: parsed 표의 content 를 parsed/chNN/ 파일로 쓰면 됨(src/parsed 에도 파일로 있음)

조회 예
  sqlite3 herb2bookdb-v7.db "select no,title,page_start_color,page_end_color from chapters"
  python3 -c "import sqlite3;c=sqlite3.connect('herb2bookdb-v7.db');print(c.execute('select label,title,page_color from figures limit 5').fetchall())"
